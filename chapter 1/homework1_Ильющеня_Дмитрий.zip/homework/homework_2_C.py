stroke = input()
for j in range(len(stroke)):
    if stroke[j].isupper() == True:
        first_letter = j
        break
for i in range(len(stroke)):
    if stroke[i].isdigit() == True:
        second_letter = i+1
        break
dot = stroke.find(".")
step = second_letter - first_letter

fin_stroke = ""
for a in range(first_letter, dot+1, step):
    fin_stroke += stroke[a]
    
print(fin_stroke)