def sdvig(l):
    ad_l = [0] * len(l)
    ad_l[0] = l[-1]
    for i in range(0, len(l)-1):
        ad_l[i+1] = l[i]
    return ad_l

ad_l = sdvig(list(map(int, input().split())))
new_str = f"{ad_l[0]}"
for i in range(1, len(ad_l)):
    new_str = new_str + " " + f"{ad_l[i]}"
print(new_str)