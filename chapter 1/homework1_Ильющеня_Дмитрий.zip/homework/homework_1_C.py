l = list(map(int, input().split()))
print(len(set(l)))