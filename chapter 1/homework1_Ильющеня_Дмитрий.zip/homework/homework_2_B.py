def boolean_check(l):
    type_cheker = ("True", "False")
    counter = 0
    if l[-1] in type_cheker:
        return l[-1]
    else:
        for j in l:
            if j in type_cheker:
                counter += 1
                prom_type = j
        if counter != 1:
            return "Can't find out"
        else:
            return prom_type

num_of_members = int(input())
main_list = []

adv_counter = [0, 0, 0]

for i in range(num_of_members):
    x = input().split()
    if boolean_check(x) == "True":
        adv_counter[0] += 1
    elif boolean_check(x) == "False":
        adv_counter[1] += 1
    else:
        adv_counter[2] += 1

print(adv_counter[0], adv_counter[1], adv_counter[2])